const withImages = require('next-images')

module.exports = withImages()
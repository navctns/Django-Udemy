from django.apps import AppConfig


class FbVideoConfig(AppConfig):
    name = 'fb_video'

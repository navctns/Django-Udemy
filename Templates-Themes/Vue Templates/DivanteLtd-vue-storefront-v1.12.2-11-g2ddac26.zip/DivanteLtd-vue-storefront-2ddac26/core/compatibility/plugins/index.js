import { EventBusPlugin } from '@vue-storefront/core/compatibility/plugins/event-bus'
import { ConfigPlugin } from '@vue-storefront/core/compatibility/plugins/config'
// used in core entrys and themes.js, deprecated bc of redundancy and for simplification of a project
export {
  EventBusPlugin,
  ConfigPlugin
}

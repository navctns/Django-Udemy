import { ProductCustomOption } from '@vue-storefront/core/modules/catalog/components/ProductCustomOption'
// renamed to ProductCustomOption and placed in catalog module
export default {
  name: 'GenericSelector',
  mixins: [ProductCustomOption]
}

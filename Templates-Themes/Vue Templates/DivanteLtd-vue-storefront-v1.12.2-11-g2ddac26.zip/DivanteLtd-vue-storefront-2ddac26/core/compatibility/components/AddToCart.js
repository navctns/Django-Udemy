import { AddToCart } from '@vue-storefront/core/modules/cart/components/AddToCart.ts'

export default {
  name: 'AddToCart',
  mixins: [ AddToCart ]
}

export default interface CmsBlockState {
  items: any[]
}

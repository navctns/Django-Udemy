import doPlatformPricesSync from './doPlatformPricesSync'

export {
  doPlatformPricesSync
}

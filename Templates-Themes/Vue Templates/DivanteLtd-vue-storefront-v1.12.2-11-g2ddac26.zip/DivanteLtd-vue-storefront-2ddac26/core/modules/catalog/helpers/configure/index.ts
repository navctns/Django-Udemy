import configureProducts from './configureProducts'

export {
  configureProducts
}

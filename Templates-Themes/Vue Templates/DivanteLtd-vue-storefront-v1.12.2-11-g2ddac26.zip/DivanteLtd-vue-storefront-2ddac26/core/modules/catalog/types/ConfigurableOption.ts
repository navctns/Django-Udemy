export interface ConfigurableItemOption {
  label: string,
  option_id: string,
  option_value: string,
  value: string
}

export default interface StockState {
  cache: any
}

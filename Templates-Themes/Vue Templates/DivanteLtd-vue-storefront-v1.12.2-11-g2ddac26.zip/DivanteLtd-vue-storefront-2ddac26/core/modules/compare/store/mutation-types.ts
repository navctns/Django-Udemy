export const SN_COMPARE = 'compare'
export const COMPARE_ADD_ITEM = `${SN_COMPARE}/ADD`
export const COMPARE_DEL_ITEM = `${SN_COMPARE}/DEL`
export const COMPARE_LOAD_COMPARE = `${SN_COMPARE}/LOAD`
export const SET_COMPARE_LOADED = `${SN_COMPARE}/SET_COMPARE_LOADED`

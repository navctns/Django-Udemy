export default interface PaymentState {
  methods: any[]
}

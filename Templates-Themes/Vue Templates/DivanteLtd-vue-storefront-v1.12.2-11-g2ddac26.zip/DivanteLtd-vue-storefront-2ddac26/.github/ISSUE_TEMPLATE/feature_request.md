---
name: Feature request
about: Suggest an idea for this project
labels: feature request

---

## What is the motivation for adding / enhancing this feature?
<!-- Describe the motivation or the concrete use case for new feature or why one of current ones should be enhanced. -->


## What are the acceptance criteria 
<!-- List the acceptance criteria for this task in a form of a list. -->

- [ ] ...

## Version of Vue Storefront
<!-- Is it next or current VSF -->
- [ ] Vue Storefront
- [ ] Vue Storefront Next

## Can you complete this feature request by yourself?

- [ ] YES
- [ ] NO

## Additional information
<!-- If you think that any additional information would be useful please provide them here. -->

